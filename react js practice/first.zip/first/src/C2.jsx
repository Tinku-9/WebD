import C3 from './C3'
function C2(){
    return(
        <div className="box">
            Component2
            <C3/>
        </div>
    );
}

export default C2