import C4 from './C4'
function C3(){
    return(
        <div className="box">
            Component3
            <C4/>
        </div>
    );
}

export default C3