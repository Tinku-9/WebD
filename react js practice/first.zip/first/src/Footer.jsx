 function Footer(){
    return(
        <footer>
            <h3>
                &copy; Year - {new Date().getFullYear()}
            </h3>
        </footer>
    );
 }

 export default Footer