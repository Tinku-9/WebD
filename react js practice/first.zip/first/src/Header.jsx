
function Header(){
    return(
        <header>
            <h1 style={{fontFamily:"fantasy"}}>My website</h1>
        </header>
        
    );
}

export default Header