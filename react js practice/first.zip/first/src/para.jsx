
import React from "react";

function Para(){
    return React.createElement("div",null,
        React.createElement("p",null,"This is paragraph without JSX.")
        );
}

export default Para